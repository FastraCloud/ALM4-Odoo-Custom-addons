# -*- coding: utf-8 -*-
# © 2014-2015 Nicolas Bessi (Camptocamp SA)
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).
from . import test_bank
from . import test_bank_type
from . import test_create_invoice
from . import test_search_invoice
