# -*- coding: utf-8 -*-

from . import res_partner
from . import account_invoice
from . import account_move_line
