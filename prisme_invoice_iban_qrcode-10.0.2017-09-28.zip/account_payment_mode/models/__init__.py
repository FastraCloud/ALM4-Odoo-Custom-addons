# -*- coding: utf-8 -*-

from . import account_payment_method
from . import account_payment_mode
from . import account_journal
from . import res_partner_bank
