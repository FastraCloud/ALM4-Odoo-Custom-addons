# -*- coding: utf-8 -*-
# License LGPL-3.0 or later (http://www.gnu.org/licenses/lgpl-3.0).

from . import test_purchase_request_to_rfq_order_approved
