Payroll-Payslip Reporting v10
=============================
This Module help Human resource managers to get a over all view for the payslips as pivot.

Features
========

* Pivot view for HR payslips.
* Group By options like Employee wise, department wise, job title wise, date wise, status wise and Company wise.
* Spot Export to XLS Report.

Credits
=======
Nikhil Krishnan @ cybrosys, nikhil@cybrosys.in