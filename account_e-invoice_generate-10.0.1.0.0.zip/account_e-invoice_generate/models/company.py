# -*- coding: utf-8 -*-
# © 2018 Akretion (Alexis de Lattre <alexis.delattre@akretion.com>)
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

from odoo import fields, models


class ResCompany(models.Model):
    _inherit = 'res.company'

    xml_format_in_pdf_invoice = fields.Selection([
        ('none', 'None'),
        ], string='XML Format embedded in PDF invoice')
