Open HRMS Employees From User
---------------------
Supporting Addon for Open HRMS, Creates Employee While Creating User

Connect with experts
--------------------

If you have any question/queries/additional works on OpenHRMS or this module, You can drop an email directly to Cybrosys.

Contacts
--------
info - info@cybrosys.com
Nilmar Shereef - shereef@cybrosys.in

Website:
https://www.openhrms.com
https://www.cybrosys.com
