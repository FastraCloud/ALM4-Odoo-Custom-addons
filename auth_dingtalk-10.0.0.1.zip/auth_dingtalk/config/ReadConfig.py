# -*- coding: utf-8 -*-

import ConfigParser
import os


class ReadConfig:

    def __init__(self):
        pass
        # self.__config = ConfigParser.ConfigParser()
        # self.__file = self._load("herp_addons/addons_v9/hq_login/config/login_param.conf")
        # self.__config.read(self.__file)

    def _get_section(self, section):
        pass
        # return self.__config.items(section)

    def _load(self, file_name):
        pass
        # return os.path.abspath(file_name)
