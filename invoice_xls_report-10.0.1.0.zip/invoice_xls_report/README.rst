=================================
Invoices/Bills Excel Report V10
=================================


Features
============
This module provides following features:
	1)You can print invoice/bills excel report through wizard.
	2)In wizard you can select start date and end date.
	3)Along with start date and end date you can also select whether the invoice state is open or paid.
	4)Along with that you have to also select whether you want to print report of customer, vendor or both.
	5)Based on the data Invoice or Bills excel report is printed.


Installation
==============
sudo pip install xlrd
sudo pip install xlwt