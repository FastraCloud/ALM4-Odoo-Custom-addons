.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
    :alt: License

Purchase Report - Product Main Group Extension
==========================================

This module adds the extra columns maningroup, second and third group to the purchase reports.

Known issues / Roadmap
======================
* None

Bug Tracker
===========
Bugs are tracked on `GitHub Issues <https://github.com/ICTSTUDIO/odoo-extra-addons/issues>`_.

Maintainer
==========
.. image:: https://www.ictstudio.eu/github_logo.png
   :alt: ICTSTUDIO
   :target: https://www.ictstudio.eu

This module is maintained by the ICTSTUDIO.