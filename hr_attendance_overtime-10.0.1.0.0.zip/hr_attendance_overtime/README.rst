HR Overtime Payment v10
=======================

Overtime payment based on attendance.

Depends
=======
[hr_payroll, hr_attendance] addon Odoo

Tech
====
* [Python] - Models
* [XML] - Odoo views

Installation
============
- www.odoo.com/documentation/10.0/setup/install.html
- Install our custom addon

License
=======
GNU LESSER GENERAL PUBLIC LICENSE, Version 3 (LGPLv3)
(http://www.gnu.org/licenses/agpl.html)

Bug Tracker
===========

Contact odoo@cybrosys.com

Authors
-------
* Cybrosys <www.cybrosys.com>

Maintainer
----------

This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com.
