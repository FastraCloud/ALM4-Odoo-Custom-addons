{
    'name': "Account Payment Print",
    'summary': """
        This Module is to show the print/preview of payment Form""",
    'description': """ Qweb Reporting of odoo V10 to show the print/preview of Payment Form.""",
    'author': "Kiran Kantesariya",
    'support': "risingsuntechcs@gmail.com",
    'license': 'AGPL-3',
    'version': '10.0.2',
    'depends': ['base','account'],
    'data': [
        'views/report_party_payment.xml',
        'views/report_external_layout_header.xml',
        'views/report_external_layout_footer.xml',
        'party_payment_report.xml',
    ],
    'demo': [
    ],
    'tests': [
    ],
}
