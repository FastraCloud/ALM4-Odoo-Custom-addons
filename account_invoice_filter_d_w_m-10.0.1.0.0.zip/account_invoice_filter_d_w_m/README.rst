Invoice Filter Today, This Week, This Month, This Year
======================================================
With Odoo <a href="https://github.com/kurniawanlucky/Odoo10.0">Invoice Filter Today, Week, Month, Year</a>,
You can filter Invoice with Today, This Week, This Month, And This Year.

This module works on Invoice page without any pre-configuration, Just install the module and enjoy it.
Provided by: Lucky Kurniawan(Kurniawanluckyy@gmail.com)

Usage
=====

* Install the module Invoice Filter Today, Week, Month, Year

Credits
=======

Contributors
------------

* Lucky Kurniawan <kurniawanluckyy@gmail.com>

