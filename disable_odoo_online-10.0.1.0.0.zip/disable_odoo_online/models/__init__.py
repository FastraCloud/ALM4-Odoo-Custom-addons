# -*- coding: utf-8 -*-
from . import publisher_warranty_contract
