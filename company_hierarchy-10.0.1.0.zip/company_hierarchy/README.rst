Company Hierarchy V10
=====================

This module will display the companies in the hierarchical structure. So that user can easily understand the
structure of the company very easily.

Configuration:
--------------
Install the module. Activate the multi company feature from the General Settings.

Here is how it works:
---------------------
    * User have to enable multi company feature;
    * Then opening the company form view you can define the company structure by defining
    the parent for each companies;
    * Settings -> Users -> Companies;
    * Then to get the Hierarchical view open the company form, click on action -> Company Hierarchy;
    * Expand the view by clicking the Arrow;

Credits
=======
Cybrosys Techno Solutions

Author
------
* Niyas Raphy <niyas@cybrosys.in>
