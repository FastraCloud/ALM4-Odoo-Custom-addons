# -*- coding: utf-8 -*-

from . import permanent_lock_date_wizard
