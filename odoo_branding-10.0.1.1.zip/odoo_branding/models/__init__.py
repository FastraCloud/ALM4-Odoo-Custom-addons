# -*- coding: utf-8 -*-

from . import odoo_remove

