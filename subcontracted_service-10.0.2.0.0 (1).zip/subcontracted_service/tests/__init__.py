# -*- coding: utf-8 -*-

from . import test_subcontracted_service
