# -*- coding: utf-8 -*-
# © 2016 Chafique DELLI @ Akretion
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

from . import res_partner
from . import supplied_product_mixin
from . import account_invoice
from . import product
from . import purchse_order
from . import product_supplierinfo
