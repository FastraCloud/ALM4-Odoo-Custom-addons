# -*- coding: utf-8 -*-
# Copyright (C) 2014 Savoir-faire Linux. All Rights Reserved.
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).
from . import test_hr_employee_firstname
