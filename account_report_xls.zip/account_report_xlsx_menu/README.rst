.. image:: https://img.shields.io/badge/license-AGPL--3-blue.png
   :target: https://www.gnu.org/licenses/agpl
   :alt: License: AGPL-3

=====================
Account Excel Reports
=====================

This module adds a menu entry *Excel Reports* to the *Accounting* menu.

It is a prerequisite for a couple of Excel accounting reports such as the 'account_journal_report_xlsx' module.

Installation
============

There is no specific installation procedure for this module.
