.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
   :target: http://www.gnu.org/licenses/agpl-3.0-standalone.html
   :alt: License: AGPL-3

===============================
Analytic Project Align Follower
===============================

By installing this module, the list of followers on an analytic account
and the list of followers on its related projects are automatically aligned.

Configuration
=============

No special configuration is needed

Credits
=======

Contributors
------------

* Antonio Esposito <a.esposito@onestein.nl>
* Andrea Stirpe <a.stirpe@onestein.nl>
