{
    'name': 'Menus Ascending Order',
    'category': 'Menus',
    "author" : "TechUltraSolutions",
    'website': 'http://www.techultrasolutions.com',
    'contect': 'TechUltra Solutions',
    'summary': '',
    'version': '10.0.1.0.0',
    'description': """
            Arrange the apps in ascending by name enterprise.

        """,
    'depends': ['base'],
    'images': ['static/description/image.png'],
    'installable': True,
    'auto_install': False,
}
