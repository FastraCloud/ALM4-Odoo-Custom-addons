.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
   :target: http://www.gnu.org/licenses/agpl-3.0-standalone.html
   :alt: License: AGPL-3

===============
Employee Number
===============


Adds an employee number generated with a sequence.


The functionality provided by this module is already
provided by the OCA module "Employee Identification Numbers"
(hr_employee_id). We suggest you to prefer the OCA module.
However, if you need a very basic and simple module that only sets
the employee number generated with a sequence, them this module
could be the right one for you.


Credits
=======

Contributors
------------

* Antonio Esposito <a.esposito@onestein.nl>
* Andrea Stirpe <a.stirpe@onestein.nl>
