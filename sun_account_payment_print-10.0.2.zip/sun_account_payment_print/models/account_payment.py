from odoo import api, fields, models, _
from odoo.tools import amount_to_text


class AccountPayment(models.Model):
    _inherit = "account.payment"

    @api.multi
    def amount_to_text(self, amount, lang='en', currency='euro'):
        return amount_to_text(amount, lang, currency)
