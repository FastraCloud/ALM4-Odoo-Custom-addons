# -*- coding: utf-8 -*-
# Copyright (c) 2017 Ignacio Ibeas Izquierdo <ignacio@acysos.com>
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).
from . import chart_template
